Date : 12/06/2012 



README for Gerber Educational BoosterPack Rev A2.zip

Files contained in the zip file:

README		      					This file
Educational BoosterPack Rev A2.cmp   			Layer top (Component)
Educational BoosterPack Rev A2.sol     			Layer bottom (Solder)
Educational BoosterPack Rev A2.stc   			Soldermask Layer top (Component)
Educational BoosterPack Rev A2.sts    			Soldermask Layer bottom (Solder)
Educational BoosterPack Rev A2.tsp    			Solder Paste Layer top 
Educational BoosterPack Rev A2.slk 			Silk Screen Layer top
Educational BoosterPack Rev A2.bsk			Silk Screen Layer bottom 
Educational BoosterPack Rev A2.bol    			Fabrication and board outline Drawing (for Ref. ONLY)
Educational BoosterPack Rev A2.drd			NC Drill file
Educational BoosterPack Rev A2.dri			Drill tool file
Educational BoosterPack Rev A2.drl			Drill tool file
Educational BoosterPack Rev A2.gpi			Extra Gerber file 
Educational BoosterPack Rev A2.brd			File layout Eagle ver 6.1
Educational BoosterPack Rev A2.sch			File schematic Eagle ver6.1
Educational BoosterPack Rev A2_CCo-Boost.lbr		File library

Notes:	PLEASE REVIEW FAB DRAWING FOR SPECIFIC REQUIREMENTS.
